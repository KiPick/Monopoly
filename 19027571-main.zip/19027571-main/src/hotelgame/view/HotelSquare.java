package hotelgame.view;

import javax.swing.*;

public class HotelSquare {

    private JLabel name;

    private JLabel starRating;

    private JLabel owner;

    private JLabel price;

    public HotelSquare(String name) {
        this.name = new JLabel(name);
    }


    public void setStarRating(String starRating) {
        this.starRating = new JLabel(starRating);
    }

    public void setOwner(String owner) {
        this.owner = new JLabel(owner);
    }

    public void setPrice(String price) {
        this.price = new JLabel(price);
    }
}
