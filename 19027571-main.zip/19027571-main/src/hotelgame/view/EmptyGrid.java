package hotelgame.view;

import javax.swing.*;
import java.awt.*;

public class EmptyGrid {

    JPanel panel = new JPanel();

    public EmptyGrid() {
        panel.setBackground(Color.WHITE);
    }

    public JPanel getPanel() {
        return panel;
    }
}
