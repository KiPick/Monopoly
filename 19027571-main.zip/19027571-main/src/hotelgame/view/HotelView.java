package hotelgame.view;

import hotelgame.controller.HotelController;
import hotelgame.model.HotelModel;

import javax.swing.*;
import java.util.Observable;
import java.util.Observer;

public class HotelView implements Observer {

    /**
     * The controller.
     */
    private HotelController controller;

    /**
     * The main Swing frame.
     */
    private JFrame frame;

    /**
     * The InfoBar containing information for the user.
     */
    private InfoBar infoBar;

    /**
     * The ActionBar containing user actions.
     */
    private ActionBar actionBar;

    /**
     * The graphical representation of the model tiles.
     */
    private Board board;

    public HotelView() {
        this.controller = new HotelController(this);
        this.frame = new JFrame("Hotel Game");
        this.setupFrame();
    }

    /**
     * Set up the Swing frame
     */
    private void setupFrame() {
        infoBar = new InfoBar();
        actionBar  = new ActionBar(controller);
        board = new Board();

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);

        frame.getContentPane().setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        frame.getContentPane().add(infoBar.getPanel());
        frame.getContentPane().add(actionBar.getPanel());
        frame.getContentPane().add(board.getPanel());
        frame.setVisible(true);

        frame.pack();
        frame.setLocationRelativeTo(null);

        this.controller.start();
    }

    @Override
    public void update(Observable observable, Object arg) {
        HotelModel model = (HotelModel) observable;
        infoBar.update(model);
        board.update(model);
    }

    /**
     * Get the action bar.
     * @return
     */
    public ActionBar getActionBar() {
        return actionBar;
    }
}