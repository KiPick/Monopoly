package hotelgame.view;

import javax.swing.*;
import java.awt.*;

public class HotelGrid {

    JPanel panel = new JPanel();

    public HotelGrid() {
        panel.setLayout(new GridLayout(11, 11));
    }

    public JPanel getPanel() {
        return panel;
    }
}
