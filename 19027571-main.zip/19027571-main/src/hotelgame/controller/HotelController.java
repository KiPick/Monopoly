package hotelgame.controller;

import hotelgame.model.Hotel;
import hotelgame.model.HotelModel;
import hotelgame.view.HotelView;

import java.util.Observer;

/**
 * The Hotel controller
 */
public class HotelController {

    /**
     * The reference to the HotelModel.
     */
    private HotelModel model;

    /**
     * The reference to the HotelView.
     */
    private HotelView view;

    public HotelController(HotelView view) {
        this.model = new HotelModel();
        this.view = view;
        this.model.addObserver(this.view);
    }

    /**
     * Start a game.
     */
    public void start() {
        this.model.reset();
        this.model.createPlayers("Player One", "Player Two");
    }

    /**
     * Roll the current player's turn.
     */
    public String rollTurn() {
        int diceRoll = model.rollDice();
        model.movePlayer(diceRoll);

        if (model.getCurrentPlayerPositionHotel() != null) {
            return getHotelResult();
        }
        return model.getCurrentTurn().getName() + " moved " + diceRoll + " and landed on an empty space.";
    }

    /**
     * Get the current player's hotel options.
     * @return
     */
    public String getHotelResult() {
        Hotel hotel = model.getCurrentPlayerPositionHotel();
        if (hotel.getOwner() == model.getCurrentTurn()) {
            view.getActionBar().enableIncreaseRating();
            return model.getCurrentTurn().getName() + " landed at your " + hotel.getName() + " hotel. The current rating of your hotel is " + hotel.getStarRating() + "/5 stars.";
        } else if (hotel.getOwner() == model.getOpposingTurn()) {
            String result = model.payOvernightFee();
            return model.getCurrentTurn().getName() + " landed at " + model.getOpposingTurn().getName() + "'s " + hotel.getName() + " hotel. " + result;
        } else {
            view.getActionBar().enableBuyHotel();
            return model.getCurrentTurn().getName() + " landed at the unpurchased " + hotel.getName() + " hotel.";
        }
    }

    /**
     * Choose to buy a hotel.
     * @return If it was successful
     */
    public String buyHotel() {
        String result = model.buyHotel();
        view.getActionBar().disableBuyHotel();

        Hotel hotel = model.getCurrentPlayerPositionHotel();
        if (hotel.getOwner() == model.getCurrentTurn()) {
            view.getActionBar().enableIncreaseRating();
        }
        return result;
    }

    /**
     * Increase the rating of a hotel.
     * @return If it was successful
     */
    public String increaseRating() {
        String result = model.increaseStarRating();
        Hotel hotel = model.getCurrentPlayerPositionHotel();
        if (hotel.getStarRating() >= 5) {
            view.getActionBar().disableIncreaseRating();
        }
        return result;
    }

    /**
     * End the current player's turn.
     */
    public String endTurn() {
        double money = model.getCurrentTurn().getMoney();
        String player = model.getCurrentTurn().getName();
        view.getActionBar().disableBuyHotel();
        view.getActionBar().disableIncreaseRating();
        view.getActionBar().disableEndTurnButton();

        if (model.isGameOver()) {
            view.getActionBar().disableRollButton();
            return model.getCurrentTurn().getName() + " have ran out of money. Game over! " + model.getOpposingTurn().getName() + " wins!";
        }
        view.getActionBar().enableRollButton();
        model.nextTurn();
        return player + "'s turn has ended with £" + money + ".";
    }

}