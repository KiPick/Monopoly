package hotelgame.model;

/**
 * This represnets a tile on the game board.
 */
public class Tile {

    /**
     * The x position of this tile.
     */
    private int xPosition;

    /**
     * The y position of this tile.
     */
    private int yPosition;

}