package hotelgame.model.tests;

import hotelgame.model.HotelModel;
import hotelgame.model.Player;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HotelModelTest {

    /**
     * Test if the game is over.
     * Set player one's money to £0
     * Set player two's money to £100
     * Assert if the game is over.
     */
    @Test
    void testGameOver() {
        HotelModel model = new HotelModel();
        model.createPlayers("one", "two");
        model.getPlayerOne().setMoney(0);
        model.getPlayerTwo().setMoney(100);

        assertTrue(model.isGameOver());
    }

    /**
     * Test if the model switches which player's turn it is.
     * Create two players
     * Save the state of the current turn in a local variable
     * Call model function to alternate urns
     * Assert the current turn is not the same
     */
    @Test
    void testNextTurn() {
        HotelModel model = new HotelModel();
        model.createPlayers("one", "two");
        Player currentTurn = model.getCurrentTurn();
        model.nextTurn();
        assertNotSame(currentTurn, model.getCurrentTurn());
    }

    /**
     * Test player movement
     * Create two players
     * Get the player of the current turn
     * Move this player 10 spaces
     * Assert the players position is now on tile 10
     */
    @Test
    void testMovePlayer() {
        HotelModel model = new HotelModel();
        model.createPlayers("one", "two");
        Player currentTurn = model.getCurrentTurn();
        model.movePlayer(10);
        assertEquals(currentTurn.getPosition(), 10);
    }

    /**
     * Test buying a hotel
     * Move a player to hotel A1
     * Attempt to buy the hotel
     * Assert a successful buy message and cost
     */
    @Test
    void testBuyHotel() {
        HotelModel model = new HotelModel();
        model.reset();
        model.createPlayers("one", "two");
        Player currentTurn = model.getCurrentTurn();
        model.movePlayer(1);
        String successBuyMessage = model.buyHotel();
        assertEquals("You have successfully bought the A1 hotel for £50.0.", successBuyMessage);
        assertEquals(currentTurn, model.getCurrentPlayerPositionHotel().getOwner());
    }

    /**
     * Test buy hotel failure
     * Set the player of the current turn's money to £0
     * Move player to hotel A1
     * Attempt to buy hotel
     * Assert failure message
     */
    @Test
    void testBuyHotelFailure() {
        HotelModel model = new HotelModel();
        model.reset();
        model.createPlayers("one", "two");
        Player currentTurn = model.getCurrentTurn();
        currentTurn.setMoney(0);
        model.movePlayer(1);
        String failureBuyMessage = model.buyHotel();
        assertEquals("You cannot afford this hotel.", failureBuyMessage);
        assertNull(model.getCurrentPlayerPositionHotel().getOwner());
    }

    /**
     * Test increasing a hotel's star rating
     * Move the current turn's player to A1
     * Buy the A1 hotel
     * Attempt to increase the star rating
     * Assert success message
     */
    @Test
    void testIncreaseStarRating() {
        HotelModel model = new HotelModel();
        model.reset();
        model.createPlayers("one", "two");
        model.movePlayer(1);
        model.buyHotel();

        String successBuyMessage = model.increaseStarRating();
        assertEquals("The hotel rating is now 1/5 stars.", successBuyMessage);
    }

    /**
     * Test increasing a hotel's star rating
     * Move the current turn's player to A1
     * Buy the A1 hotel
     * Set player's money to £0
     * Attempt to increase the star rating
     * Assert failure message
     */
    @Test
    void testIncreaseStarRatingFailure() {
        HotelModel model = new HotelModel();
        model.reset();
        model.createPlayers("one", "two");
        model.movePlayer(1);
        model.buyHotel();
        model.getCurrentTurn().setMoney(0);

        String failureBuyMessage = model.increaseStarRating();
        assertEquals("You do not have enough money to increase the rating of this hotel.", failureBuyMessage);
        assertEquals(0, model.getCurrentPlayerPositionHotel().getStarRating());
    }

    /**
     * Move current player to A1
     * Buy A1 Hotel
     * Increase A1 star rating
     * Switch to other player's turn
     * Move other player to A1
     * Attempt to pay overnight fees
     * Assert successful message
     * Assert other player's money was decreased
     * Assert first player's money was increased
     */
    @Test
    void testPayOvernightFee() {
        HotelModel model = new HotelModel();
        model.reset();
        model.createPlayers("one", "two");
        model.movePlayer(1);
        model.buyHotel();
        model.increaseStarRating();
        model.nextTurn();

        model.movePlayer(1);
        String successOvernightFeeMessage = model.payOvernightFee();
        assertEquals("You were charged £5.0 for staying at this hotel.", successOvernightFeeMessage);
        assertEquals(1995, model.getCurrentTurn().getMoney());
        assertEquals(1930, model.getOpposingTurn().getMoney());
    }

    /**
     * Move current turn's player to A1
     * Buy A1 hotel
     * Switch to other player's turn
     * Move other player to A1
     * Assert other player does not pay fee due to 0 star rating
     */
    @Test
    void testPayOvernightFeeNoRating() {
        HotelModel model = new HotelModel();
        model.reset();
        model.createPlayers("one", "two");
        model.movePlayer(1);
        model.buyHotel();
        model.nextTurn();
        model.movePlayer(1);

        String overnightFeeMessage = model.payOvernightFee();
        assertEquals("You do not have to pay a fee at this hotel because the rating is 0.", overnightFeeMessage);
    }
}