package hotelgame.model;

import java.util.Observable;

public class HotelModel extends Observable {

    public final static int MAX_TILES = 40;

    private final int DICE_ROLL = 12;

    /**
     * The Player whose turn it currently is
     */
    private Player currentTurn;

    /**
     * The first player.
     */
    private Player playerOne;

    /**
     * The second player.
     */
    private Player playerTwo;

    /**
     * All the tiles in the game.
     * There are always 40 total.
     * If a tile is null, there is not a Hotel located there.
     */
    private Hotel[] tiles;

    /**
     * The latest dice roll by the current player.
     */
    private int currentRoll;

    public Player getPlayerOne() {
        return playerOne;
    }

    public Player getPlayerTwo() {
        return playerTwo;
    }

    /**
     * Roll the dice for the current player.
     */
    public int rollDice() {
        currentRoll = (int) Math.ceil(Math.random() * DICE_ROLL);
        return currentRoll;
    }

    /**
     * Determine if the game is over by checking if either player has 0 money left.
     * @return boolean
     */
    public boolean isGameOver() {
        return playerOne.getMoney() <= 0 || playerTwo.getMoney() <= 0;
    }

    /**
     * Buy a hotel for the current player.
     * @return String the result of attempting to buy the hotel
     */
    public String buyHotel() {
        Hotel hotel = this.getCurrentPlayerPositionHotel();
        Player  player = this.getCurrentTurn();
        if (hotel == null || hotel.getOwner() != null) {
            return "You cannot buy this hotel";
        }

        if (hotel.getPrice() > player.getMoney()) {
            return "You cannot afford this hotel.";
        }

        player.deductMoney(hotel.getPrice());
        if (player.getMoney() > 0) {
            hotel.setOwner(player);
        }
        this.setChanged();
        notifyObservers();
        return "You have successfully bought the " + hotel.getName() + " hotel for £" + hotel.getPrice() + ".";
    }

    /**
     * Increase the rating of a hotel.
     * The current player will be the one increasing.
     */
    public String increaseStarRating() {
        Hotel hotel = this.getCurrentPlayerPositionHotel();
        Player player = this.getCurrentTurn();

        if (hotel == null || hotel.getOwner() != player) {
            return "You do not own this hotel.";
        }

        double increaseRatingCost = hotel.getIncreaseRatingFee();
        if (player.getMoney() > increaseRatingCost) {
            player.deductMoney(increaseRatingCost);
            hotel.increaseStarRating();
            this.setChanged();
            this.notifyObservers();
            return "The hotel rating is now " + hotel.getStarRating() + "/5 stars.";
        } else {
            return "You do not have enough money to increase the rating of this hotel.";
        }
    }

    /**
     * Pay overnight fees for the current player.
     */
    public String payOvernightFee() {
        Hotel hotel = this.getCurrentPlayerPositionHotel();
        Player player = this.getCurrentTurn();
        if (hotel == null || hotel.getOwner() == null || hotel.getOwner() == player) {
            return "You do not have to pay a fee at this hotel.";
        }

        double overnightCost = calculateCurrentHotelFee();
        if (overnightCost > 0) {
            player.deductMoney(overnightCost);
            this.getOpposingTurn().addMoney(overnightCost);
            return "You were charged £" + overnightCost + " for staying at this hotel.";
        }
        this.setChanged();
        this.notifyObservers();
        return "You do not have to pay a fee at this hotel because the rating is 0.";
    }

    /**
     * Calculate the current player's hotel fees.
     * @return
     */
    private double calculateCurrentHotelFee() {
        Hotel hotel = this.getCurrentPlayerPositionHotel();
        Player player = this.getCurrentTurn();

        if (hotel == null || hotel != null && hotel.getOwner() == player) {
            return 0;
        }

        Player opposingPlayer = this.getOpposingTurn();
        int position = hotel.getPosition();
        Hotel neighborOne = position > 0 ? tiles[position - 1] : null;
        Hotel neighborTwo = position < 40 ? tiles[position + 1] : null;

        double overnightCost = hotel.getOvernightFee();
        if (neighborOne != null && neighborOne.getOwner() == opposingPlayer &&
            neighborTwo != null && neighborTwo.getOwner() == opposingPlayer) {
            overnightCost *= 2;
        } else if (neighborOne != null && neighborOne.getOwner() == player ||
            neighborTwo != null && neighborTwo.getOwner() == player) {
            overnightCost /= 2;
        }
        return overnightCost;
    }

    /**
     * Move the current player.
     * @param amount The amount of tiles to move.
     */
    public void movePlayer(int amount) {
        int currentPosition = this.getCurrentTurn().getPosition();
        int newPosition = currentPosition + amount;
        if (newPosition > MAX_TILES - 1) {
            newPosition -= MAX_TILES;
        }
        this.getCurrentTurn().setPosition(newPosition);
        this.setChanged();
        this.notifyObservers();
    }

    /**
     * Shift the turn to the next player.
     */
    public void nextTurn() {
        if (this.currentTurn == this.playerOne) {
            this.currentTurn = this.playerTwo;
        } else {
            this.currentTurn = this.playerOne;
        }
        this.setChanged();
        this.notifyObservers();
    }

    /**
     * Get the hotel (or null) at the current player's position
     * @return The hotel or null value at the current player's position
     */
    public Hotel getCurrentPlayerPositionHotel() {
        return tiles[this.getCurrentTurn().getPosition()];
    }

    public void createPlayers(String playerOneName, String playerTwoName) {
        playerOne = new Player(playerOneName);
        playerTwo = new Player(playerTwoName);
        currentTurn = Math.ceil(Math.random() * 2) == 1 ? playerOne : playerTwo;
        this.setChanged();
        this.notifyObservers();
    }

    /**
     * Reset this model to the beginning of a new game.
     */
    public void reset() {
        playerOne = null;
        playerTwo = null;
        currentTurn = null;

        tiles = generateTiles();
        this.notifyObservers();
    }

    /**
     * Generate the game's Hotel tiles.
     * @return
     */
    private Hotel[] generateTiles() {
        Hotel[] tiles = new Hotel[MAX_TILES];
        char startingHotelLetter = 65;
        for(int hotelLetter = 0; hotelLetter < 8; hotelLetter++) {
            int hotelNumber = 1;
            for (int tileNumber = 0; tileNumber < 5; tileNumber++) {
                int tilePosition = (hotelLetter * 5) + tileNumber;
                if (tileNumber == 0 || tileNumber == 2) {
                    tiles[tilePosition] = null;
                } else {
                    int price = (hotelLetter + 1) * 50 + (tileNumber == 4 ? 20 : 0);
                    tiles[tilePosition] = new Hotel(String.valueOf((char) (startingHotelLetter + hotelLetter)) + hotelNumber, tilePosition, price);
                    hotelNumber++;
                }
            }
        }
        return tiles;
    }

    /**
     * Get the current turn's player.
     * @return
     */
    public Player getCurrentTurn() {
        return currentTurn;
    }

    /**
     * Get the current turn's opposing player.
     * @return
     */
    public Player getOpposingTurn() {
        return currentTurn == playerOne ? playerTwo : playerOne;
    }


    /**
     * Get the current player's dice roll.
     * @return
     */
    public int getCurrentRoll() {
        return currentRoll;
    }

    /**
     * Get the current hotel tiles.
     * @return
     */
    public Hotel[] getTiles() {
        return tiles;
    }
}