package hotelgame.view;

import hotelgame.controller.HotelController;
import hotelgame.model.HotelModel;

import javax.swing.*;
import java.util.Observable;
import java.util.Observer;

public class HotelView implements Observer {

    private HotelController controller;

    private HotelModel model;

    private JFrame frame;

    private JLabel turn;

    private JLabel playerOneMoney;

    private JLabel playerTwoMoney;

    private JLabel rollResult;

    private JButton rollButton;

    private JButton buyHotel;

    private JButton increaseRating;


    @Override
    public void update(Observable o, Object arg) {

    }

    public void rollTurn() {

    }

    public void buyHotel() {

    }

    public void enableRollButton() {

    }

    public void enableBuyHotel() {

    }

    public void enableIncreaseRating() {

    }

    public void disableRollButton() {

    }

    public void disableBuyHotel() {

    }

    public void disableIncreaseRating() {

    }
}