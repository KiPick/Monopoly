package hotelgame.controller;

import hotelgame.model.HotelModel;
import hotelgame.view.HotelView;

/**
 * The Hotel hotelgame.controller
 */
public class HotelController {

    /**
     * The reference to the HotelModel.
     */
    private HotelModel model;

    /**
     * The reference to the HotelView.
     */
    private HotelView view;

    /**
     * Roll the current player's turn.
     */
    public void rollTurn() {

    }

    /**
     * Choose to buy a hotel.
     * @return If it was successful
     */
    public boolean buyHotel() {
        return false;
    }

    /**
     * Increase the rating of a hotel.
     * @return If it was successful
     */
    public boolean increaseRating() {
        return false;
    }

    /**
     * Pay an overnight fee.
     * @return If it was successful
     */
    public boolean payOvernightFee() {
        return false;
    }

}