package hotelgame;

import hotelgame.model.Hotel;
import hotelgame.model.HotelModel;

import java.util.Scanner;

public class CLIMain {

    private HotelModel model;

    private Scanner reader;

    public CLIMain() {
        model = new HotelModel();
        reader = new Scanner(System.in);
    }

    public static void main(String[] args) {
        System.out.println("Welcome to the Hotel Game!");

        CLIMain cli = new CLIMain();
        cli.promptNewGame();
    }

    private void promptNewGame() {
        System.out.print("Press s to start a new game or q to quit: ");
        String answer = reader.nextLine();

        if (answer.equalsIgnoreCase("s")) {
            startNewGame();
        } else if (answer.equalsIgnoreCase("q"))  {
            quitGame();
        } else {
            System.out.println("Invalid input, please try again");
            promptNewGame();
        }
    }

    private void quitGame() {
        System.out.println("Thanks for playing the Hotel Game!");
        reader.close();
    }

    private void startNewGame() {
        model.reset();

        String playerOneName = getPlayerName("one");
        String playerTwoName = getPlayerName("two");

        model.createPlayers(playerOneName, playerTwoName);
        System.out.println("Player " + model.getCurrentTurn().getName() + " will go first.");

        playGame();
    }

    private String getPlayerName(String number) {
        String playerName = "";
        while (playerName.equals("")) {
            System.out.print("Press enter player " + number + "'s name: ");
            playerName = reader.nextLine();
            if (playerName.equals("")) {
                System.out.println("Invalid player name, please try again.");
            }
        }
        return playerName;
    }

    private void playGame() {
        while(!model.isGameOver()) {
            System.out.print(model.getCurrentTurn().getName() + " press any key to roll the dice for your turn: ");
            reader.next();

            int diceRoll = model.rollDice();
            model.movePlayer(diceRoll);
            System.out.println("You moved " + diceRoll + " spaces.");

            if (model.getCurrentPlayerPositionHotel() != null) {
                showHotelOptions();
            } else {
                System.out.println("You landed on a blank tile: " + model.getCurrentTurn().getPosition());
            }

            System.out.println("Your turn has ended with " + model.getCurrentTurn().getMoney() + ".");
            System.out.println();
            model.nextTurn();
        }
    }

    private void showHotelOptions() {
        Hotel hotel = model.getCurrentPlayerPositionHotel();

        if (hotel.getOwner() == model.getCurrentTurn()) {
            System.out.println("You landed at your " + hotel.getName() + " hotel.");
            showIncreaseRatingOptions();
        } else if (hotel.getOwner() == model.getOpposingTurn()) {
            System.out.println("You landed at " + model.getOpposingTurn().getName() + "'s " + hotel.getName() + " hotel.");
            String result = model.payOvernightFee();
            System.out.println(result);
            System.out.println();
        } else {
            System.out.println("You landed at the unpurchased " + hotel.getName() + " hotel.");
            System.out.println("Would you like to buy this hotel for " + hotel.getPrice() + " ?");
            System.out.print("Press y to buy or any other key to skip: ");
            String answer = reader.next();
            if (answer.equalsIgnoreCase("y")) {
                String result = model.buyHotel();
                System.out.println(result);
                System.out.println();
                showIncreaseRatingOptions();
            }
        }
    }

    private void showIncreaseRatingOptions() {
        Hotel hotel = model.getCurrentPlayerPositionHotel();
        System.out.println("The current rating of your hotel is " + hotel.getStarRating() + "/5 stars.");
        if (hotel.getStarRating() < 5) {
            System.out.println("Would you like to increase the rating for a cost of " + hotel.getIncreaseRatingFee() + "?");
            System.out.print("Press y to increase the rating or any other key to skip: ");
            String answer = reader.next();
            if (answer.equalsIgnoreCase("y")) {
                String result = model.increaseStarRating();
                System.out.println(result);
                System.out.println();
                showIncreaseRatingOptions();
            }
        }
    }

}