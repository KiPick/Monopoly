package hotelgame.model;

/**
 * A Hotel on the board of the game.
 */
public class Hotel {

    /**
     * The name of the hotel.
     */
    private String name;

    /**
     * The rating the hotel has.
     */
    private int starRating;

    /**
     * The position of the hotel in the game.
     */
    private int position;

    /**
     * The price of the hotel.
     */
    private double price;

    /**
     * The player that owns the hotel.
     */
    private Player owner;

    public Hotel(String name, int position, int price) {
        this.name = name;
        this.position = position;
        this.price = price;
        this.starRating = 0;
    }

    public String getName() {
        return name;
    }

    public int getStarRating() {
        return starRating;
    }

    public int getPosition() {
        return position;
    }

    public void increaseStarRating() {
        this.starRating++;
    }

    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player owner) {
        this.owner = owner;
    }

    public double getPrice() {
        return price;
    }

    public double getOvernightFee() {
        return (0.10 * this.price) * this.starRating;
    }

    public double getIncreaseRatingFee() {
        return this.price * 0.50;
    }
}