package hotelgame.model;

/**
 * This class represents a player of the Hotel Game.
 */
public class Player {

    /**
     * The amount of money this player has.
     */
    private double money;

    /**
     * This player's display name.
     */
    private String name;

    /**
     * This player's current position in the game.
     */
    private int position;

    public Player(String name) {
        this.name = name;
        this.money = 2000;
        this.position = 0;
    }

    public double getMoney() {
        return money;
    }

    public String getName() {
        return name;
    }

    public int getPosition() {
        return position;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public void deductMoney(double amount) {
        this.money -= amount;
    }

    public void addMoney(double amount) {
        this.money += amount;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}