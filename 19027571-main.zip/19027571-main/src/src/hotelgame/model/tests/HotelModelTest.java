package hotelgame.model.tests;

import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import hotelgame.model.HotelModel;
import hotelgame.model.Player;
import org.junit.jupiter.api.Test;

class HotelModelTest {

    @Test
    void testGameOver() {
        HotelModel model = new HotelModel();
        model.createPlayers("one", "two");
        model.getPlayerOne().setMoney(0);
        model.getPlayerTwo().setMoney(0);

        assertTrue(model.isGameOver());
    }

    @Test
    void testNextTurn() {
        HotelModel model = new HotelModel();
        model.createPlayers("one", "two");
        Player currentTurn = model.getCurrentTurn();
        model.nextTurn();
        assertNotSame(currentTurn, model.getCurrentTurn());
    }
}